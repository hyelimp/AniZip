import React from "react";
import Container from 'react-bootstrap/Container';
import '../css/footer.css';

const url = "https://comicw.co.kr/";

const Footer = () => {
    return(
        <div className="Foot">
            <Container>
                <br /><br />
                <hr />
                <img
                    className="f_logo"
                    src="/images/icon.png"
                    alt="푸터로고"
                    />
                <p className="f_address">회사 주소 : 서울시 행복한구 즐거운아파트 101동 1004호, 연락처 : 010-1234-7979
                <br />
                COPYRIGNT &copy; PARK HYE LIM ALL RIGHTS RESERVED.</p>
                <br />
                <button className="f_btn" onClick={()=>{window.open(url)}} >코믹월드 웹사이트 바로가기</button>
            </Container>
        </div>
    );
};

export default Footer;